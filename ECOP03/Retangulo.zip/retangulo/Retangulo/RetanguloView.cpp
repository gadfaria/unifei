
// RetanguloView.cpp : implementation of the CRetanguloView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Retangulo.h"
#endif

#include "RetanguloDoc.h"
#include "RetanguloView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CRetanguloView

IMPLEMENT_DYNCREATE(CRetanguloView, CView)

BEGIN_MESSAGE_MAP(CRetanguloView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
//	ON_COMMAND(ID_ALTERA_TAMANHO, &CRetanguloView::OnAlteraTamanho)
END_MESSAGE_MAP()

// CRetanguloView construction/destruction

CRetanguloView::CRetanguloView()
	: m_centro(200,200)
	, m_sinalY(1)
	, m_sinalX(1)
	, m_cor(RGB(rand() % 255, rand() % 255, rand() % 255))
	, m_tam(30)
{
	// TODO: add construction code here
	

}

CRetanguloView::~CRetanguloView()
{
}

BOOL CRetanguloView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CRetanguloView drawing

void CRetanguloView::OnDraw(CDC* pDC)
{
	CRetanguloDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	// TODO: add draw code for native data here
	
	CBrush *antiga, nova(m_cor);
	antiga = pDC->SelectObject(&nova);

	pDC->Rectangle(m_centro.x - m_tam, m_centro.y - m_tam, m_centro.x + m_tam, m_centro.y + m_tam);

	pDC->SelectObject(antiga);
}


// CRetanguloView printing

BOOL CRetanguloView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CRetanguloView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CRetanguloView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CRetanguloView diagnostics

#ifdef _DEBUG
void CRetanguloView::AssertValid() const
{
	CView::AssertValid();
}

void CRetanguloView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CRetanguloDoc* CRetanguloView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRetanguloDoc)));
	return (CRetanguloDoc*)m_pDocument;
}
#endif //_DEBUG


// CRetanguloView message handlers


void CRetanguloView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	SetTimer(1, 100, NULL);
	// TODO: Add your specialized code here and/or call the base class
}


void CRetanguloView::OnDestroy()
{
	CView::OnDestroy();

	KillTimer(1);
	// TODO: Add your message handler code here
}


void CRetanguloView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	CRect tela;
	GetClientRect(&tela);
	
	m_centro.x += 5 * m_sinalX;
	if (((m_centro.x + m_tam) > tela.Width()) || ((m_centro.x - m_tam) < 0)){
		m_sinalX *= -1;
		m_cor = (RGB(rand() % 255, rand() % 255, rand() % 255));
	}

	m_centro.y += 5 * m_sinalY;
	if (((m_centro.y + m_tam) > tela.Height()) || ((m_centro.y - m_tam) < 0)){
		m_sinalY *= -1;
		m_cor = (RGB(rand() % 255, rand() % 255, rand() % 255));
	}

	Invalidate();

	CView::OnTimer(nIDEvent);
}


void CRetanguloView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_centro = point;
	CView::OnLButtonDown(nFlags, point);
}


//void CRetanguloView::OnAlteraTamanho()
//{
//	CTamanhoDlg dlg;
//
//	// TODO: Add your command handler code here
//}
