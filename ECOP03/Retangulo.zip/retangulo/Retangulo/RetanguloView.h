
// RetanguloView.h : interface of the CRetanguloView class
//

#pragma once
#include "atltypes.h"


class CRetanguloView : public CView
{
protected: // create from serialization only
	CRetanguloView();
	DECLARE_DYNCREATE(CRetanguloView)

// Attributes
public:
	CRetanguloDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CRetanguloView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

public:
	COLORREF m_cor;
public:
	// centro do retangulo 
	CPoint m_centro;
	// guarda o sinal da variavel de incremento
	int m_sinalY;
	int m_sinalX;
	virtual void OnInitialUpdate();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
//	int m_tamanho;
	int m_tam;
//	afx_msg void OnAlteraTamanho();
};

#ifndef _DEBUG  // debug version in RetanguloView.cpp
inline CRetanguloDoc* CRetanguloView::GetDocument() const
   { return reinterpret_cast<CRetanguloDoc*>(m_pDocument); }
#endif

