
// Retangulo.h : main header file for the Retangulo application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CRetanguloApp:
// See Retangulo.cpp for the implementation of this class
//

class CRetanguloApp : public CWinApp
{
public:
	CRetanguloApp();


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CRetanguloApp theApp;
