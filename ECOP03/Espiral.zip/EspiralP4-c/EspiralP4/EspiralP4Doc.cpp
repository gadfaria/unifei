
// EspiralP4Doc.cpp : implementation of the CEspiralP4Doc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "EspiralP4.h"
#endif

#include "EspiralP4Doc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CEspiralP4Doc

IMPLEMENT_DYNCREATE(CEspiralP4Doc, CDocument)

BEGIN_MESSAGE_MAP(CEspiralP4Doc, CDocument)
END_MESSAGE_MAP()


// CEspiralP4Doc construction/destruction

CEspiralP4Doc::CEspiralP4Doc() :  m_centro(0)
								, m_escala(0.1)
								, m_cor(RGB(0xFF, 0, 0))
{
	// TODO: add one-time construction code here

}

CEspiralP4Doc::~CEspiralP4Doc()
{
}

BOOL CEspiralP4Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CEspiralP4Doc serialization

void CEspiralP4Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_centro << m_cor << m_escala;
	}
	else
	{
		ar >> m_centro >> m_cor >> m_escala;
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CEspiralP4Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CEspiralP4Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CEspiralP4Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CEspiralP4Doc diagnostics

#ifdef _DEBUG
void CEspiralP4Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEspiralP4Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CEspiralP4Doc commands
