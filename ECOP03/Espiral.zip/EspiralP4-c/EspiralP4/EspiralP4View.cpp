
// EspiralP4View.cpp : implementation of the CEspiralP4View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "EspiralP4.h"
#endif

#include "EspiralP4Doc.h"
#include "EspiralP4View.h"


#include "EscalaDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEspiralP4View

IMPLEMENT_DYNCREATE(CEspiralP4View, CView)

BEGIN_MESSAGE_MAP(CEspiralP4View, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_ALTERAR_COR, &CEspiralP4View::OnAlterarCor)
	ON_COMMAND(ID_ALTERAR_ESCALA, &CEspiralP4View::OnAlterarEscala)
	ON_COMMAND(ID_ALTERAR_TIMER, &CEspiralP4View::OnAlterarTimer)
	ON_UPDATE_COMMAND_UI(ID_ALTERAR_TIMER, &CEspiralP4View::OnUpdateAlterarTimer)
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CEspiralP4View construction/destruction

CEspiralP4View::CEspiralP4View()
	: m_angInicial(0)
	, m_bPressionado(false)
	, m_nTimer(0)
{
	// TODO: add construction code here

}

CEspiralP4View::~CEspiralP4View()
{
}

BOOL CEspiralP4View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CEspiralP4View drawing

void CEspiralP4View::OnDraw(CDC* pDC)
{
	CEspiralP4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
	CRect tela;
	GetClientRect(&tela);
	CPoint centro;
	//centro.x = tela.Width() / 2;
	//centro.y = tela.Height() / 2;
	centro = pDoc->m_centro;
	CPen *original, nova(PS_SOLID, 5,  pDoc->m_cor);
	original = pDC->SelectObject(&nova);

	pDC->MoveTo(centro);
	for (int i = 0; i < 360 * 4; i++){
		//CPen outra(PS_SOLID, 15, RGB(rand() % 255, rand() % 255, rand() % 255));
		//pDC->SelectObject(&outra);
		int x =  pDoc->m_escala*i * cos((i + m_angInicial)*3.1415 / 180) + centro.x;
		int y =  pDoc->m_escala*i * sin((i + m_angInicial)*3.1415 / 180) + centro.y;
		pDC->LineTo(x, y);
	}
	//m_angInicial +=3 ;

	pDC->SelectObject(original);
}


// CEspiralP4View printing

BOOL CEspiralP4View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CEspiralP4View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CEspiralP4View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CEspiralP4View diagnostics

#ifdef _DEBUG
void CEspiralP4View::AssertValid() const
{
	CView::AssertValid();
}

void CEspiralP4View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEspiralP4Doc* CEspiralP4View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEspiralP4Doc)));
	return (CEspiralP4Doc*)m_pDocument;
}
#endif //_DEBUG


// CEspiralP4View message handlers


void CEspiralP4View::OnLButtonDown(UINT nFlags, CPoint point)
{
	CEspiralP4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	// TODO: Add your message handler code here and/or call default
	pDoc->m_centro = point;
	//Invalidate(false);
	pDoc->UpdateAllViews(NULL);
	pDoc->SetModifiedFlag();
	m_bPressionado = true;
	SetCapture();

	CView::OnLButtonDown(nFlags, point);
}


void CEspiralP4View::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_bPressionado = false;
	ReleaseCapture();

	CView::OnLButtonUp(nFlags, point);
}


void CEspiralP4View::OnMouseMove(UINT nFlags, CPoint point)
{
	CEspiralP4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: Add your message handler code here and/or call default
	if (m_bPressionado)
	{
		pDoc->m_centro = point;
		//Invalidate(false);
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
	CView::OnMouseMove(nFlags, point);
}


void CEspiralP4View::OnAlterarCor()
{
	CEspiralP4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	CColorDialog dlg;
	if (dlg.DoModal() == IDOK){
		pDoc->m_cor = dlg.GetColor();
		//Invalidate(false);
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}


void CEspiralP4View::OnAlterarEscala()
{
	CEspiralP4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: Add your command handler code here
	CEscalaDlg dlg;
	dlg.m_escala = pDoc->m_escala;

	if (dlg.DoModal() == IDOK){
		pDoc->m_escala = dlg.m_escala;
		//Invalidate(false);
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}


void CEspiralP4View::OnAlterarTimer()
{
	// TODO: Add your command handler code here
	if (m_nTimer == 0){
		m_nTimer = SetTimer(1, 100, NULL);
	}
	else{
		KillTimer(m_nTimer);
		m_nTimer = 0;
	}
}


void CEspiralP4View::OnUpdateAlterarTimer(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nTimer);
}


void CEspiralP4View::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	m_angInicial += 5;
	Invalidate();
	CView::OnTimer(nIDEvent);
}
