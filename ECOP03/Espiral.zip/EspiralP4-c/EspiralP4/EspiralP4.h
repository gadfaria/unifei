
// EspiralP4.h : main header file for the EspiralP4 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CEspiralP4App:
// See EspiralP4.cpp for the implementation of this class
//

class CEspiralP4App : public CWinApp
{
public:
	CEspiralP4App();


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CEspiralP4App theApp;
