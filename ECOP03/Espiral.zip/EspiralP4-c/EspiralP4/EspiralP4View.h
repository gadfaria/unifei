
// EspiralP4View.h : interface of the CEspiralP4View class
//

#pragma once
#include "atltypes.h"


class CEspiralP4View : public CView
{
protected: // create from serialization only
	CEspiralP4View();
	DECLARE_DYNCREATE(CEspiralP4View)

// Attributes
public:
	CEspiralP4Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CEspiralP4View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	// guarda o angulo inicial da espiral
	int m_angInicial;

public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
protected:
	// true se o botao estiver pressionado
	bool m_bPressionado;

public:
	afx_msg void OnAlterarCor();
	afx_msg void OnAlterarEscala();
	afx_msg void OnAlterarTimer();
	afx_msg void OnUpdateAlterarTimer(CCmdUI *pCmdUI);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	// armazena o numero do timer, ou zero caso ele esteja desligado
	unsigned int m_nTimer;
};

#ifndef _DEBUG  // debug version in EspiralP4View.cpp
inline CEspiralP4Doc* CEspiralP4View::GetDocument() const
   { return reinterpret_cast<CEspiralP4Doc*>(m_pDocument); }
#endif

