// EscalaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EspiralP4.h"
#include "EscalaDlg.h"
#include "afxdialogex.h"


// CEscalaDlg dialog

IMPLEMENT_DYNAMIC(CEscalaDlg, CDialogEx)

CEscalaDlg::CEscalaDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CEscalaDlg::IDD, pParent)
	, m_escala(0)
{

}

CEscalaDlg::~CEscalaDlg()
{
}

void CEscalaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_ESCALA, m_escala);
	DDV_MinMaxDouble(pDX, m_escala, 0, 2);
}


BEGIN_MESSAGE_MAP(CEscalaDlg, CDialogEx)
END_MESSAGE_MAP()


// CEscalaDlg message handlers
