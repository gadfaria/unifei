#pragma once


// CEscalaDlg dialog

class CEscalaDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CEscalaDlg)

public:
	CEscalaDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEscalaDlg();

// Dialog Data
	enum { IDD = IDD_ESCALA };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	double m_escala;
};
